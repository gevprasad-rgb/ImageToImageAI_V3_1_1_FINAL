package com.prasad.image2image.provider;

import java.util.HashMap;
import java.util.Map;

public final class ProviderRegistry {
    private final Map<String, ProviderAdapter> adapters = new HashMap<>();

    public void register(ProviderAdapter adapter) {
        adapters.put(adapter.getProviderId(), adapter);
    }

    public ProviderAdapter get(String providerId) {
        ProviderAdapter adapter = adapters.get(providerId);
        if (adapter == null) throw new IllegalArgumentException("Provider not registered: " + providerId);
        return adapter;
    }
}
