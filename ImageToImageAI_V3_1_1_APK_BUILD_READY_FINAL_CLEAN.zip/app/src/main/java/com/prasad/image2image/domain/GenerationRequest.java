package com.prasad.image2image.domain;

public final class GenerationRequest {
    public final String clientRequestId;
    public final TaskId taskId;
    public final String providerId;
    public final String prompt;
    public final String negativePrompt;
    public final String aspectRatio;
    public final String profile;
    public final String model;
    public final int preserve;
    public final float cfg;
    public final int steps;
    public final long seed;
    public final String sourceUri;

    public GenerationRequest(String clientRequestId, TaskId taskId, String providerId,
                             String prompt, String negativePrompt, String aspectRatio,
                             String profile, String model, int preserve, float cfg,
                             int steps, long seed, String sourceUri) {
        this.clientRequestId = clientRequestId;
        this.taskId = taskId;
        this.providerId = providerId;
        this.prompt = prompt;
        this.negativePrompt = negativePrompt;
        this.aspectRatio = aspectRatio;
        this.profile = profile;
        this.model = model;
        this.preserve = preserve;
        this.cfg = cfg;
        this.steps = steps;
        this.seed = seed;
        this.sourceUri = sourceUri;
    }

    /**
     * Serializes generation parameters without depending on Android framework JSON APIs.
     * This keeps the domain model usable from JVM unit tests and preserves valid JSON
     * escaping for user-controlled string parameters.
     */
    public String parametersJson() {
        StringBuilder json = new StringBuilder(192);
        json.append('{');
        appendString(json, "aspectRatio", aspectRatio);
        json.append(',');
        appendString(json, "profile", profile);
        json.append(',');
        appendString(json, "model", model);
        json.append(',');
        appendInt(json, "preserve", preserve);
        json.append(',');
        appendFloat(json, "cfg", cfg);
        json.append(',');
        appendInt(json, "steps", steps);
        json.append(',');
        appendLong(json, "seed", seed);
        json.append('}');
        return json.toString();
    }

    private static void appendString(StringBuilder out, String key, String value) {
        quote(out, key);
        out.append(':');
        if (value == null) out.append("null");
        else quote(out, value);
    }

    private static void appendInt(StringBuilder out, String key, int value) {
        quote(out, key).append(':').append(value);
    }

    private static void appendLong(StringBuilder out, String key, long value) {
        quote(out, key).append(':').append(value);
    }

    private static void appendFloat(StringBuilder out, String key, float value) {
        if (!Float.isFinite(value)) {
            throw new IllegalArgumentException("cfg must be finite");
        }
        quote(out, key).append(':').append(Float.toString(value));
    }

    private static StringBuilder quote(StringBuilder out, String value) {
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        out.append("\\u");
                        String hex = Integer.toHexString(c);
                        for (int p = hex.length(); p < 4; p++) out.append('0');
                        out.append(hex);
                    } else {
                        out.append(c);
                    }
            }
        }
        return out.append('"');
    }
}
