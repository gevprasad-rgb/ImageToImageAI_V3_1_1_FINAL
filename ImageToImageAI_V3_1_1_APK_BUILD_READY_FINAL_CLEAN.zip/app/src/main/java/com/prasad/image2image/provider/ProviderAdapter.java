package com.prasad.image2image.provider;

import com.prasad.image2image.domain.GenerationRequest;
import com.prasad.image2image.domain.ProviderCapability;

public interface ProviderAdapter {
    String getProviderId();
    ProviderCapability getCapabilities() throws Exception;
    java.util.List<String> getModels() throws Exception;
    void healthCheck() throws Exception;
    ProviderResult generate(GenerationRequest request, byte[] sourceImage) throws Exception;

    default ProviderReconciliation reconcile(String clientRequestId) throws Exception {
        return ProviderReconciliation.notFound();
    }
}
