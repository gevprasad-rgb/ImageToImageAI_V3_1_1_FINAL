package com.prasad.image2image.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface ProjectDao {
    @Insert
    long insert(ProjectEntity project);

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    ProjectEntity findById(long id);

    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    java.util.List<ProjectEntity> getAll();
}
