package com.prasad.image2image.domain;

import java.util.EnumSet;
import java.util.Set;

public enum GenerationJobState {
    CREATED,
    VALIDATING,
    UPLOADING,
    SUBMITTED,
    QUEUED,
    GENERATING,
    DOWNLOADING,
    PROCESSING,
    VALIDATING_OUTPUT,
    COMPLETED,
    FAILED,
    CANCELLED,
    RETRYING,
    UNKNOWN;

    public boolean canTransitionTo(GenerationJobState next) {
        if (this == next) return true;
        Set<GenerationJobState> allowed;
        switch (this) {
            case CREATED:
                allowed = EnumSet.of(VALIDATING, CANCELLED, FAILED);
                break;
            case VALIDATING:
                allowed = EnumSet.of(UPLOADING, SUBMITTED, GENERATING, FAILED, CANCELLED);
                break;
            case UPLOADING:
                allowed = EnumSet.of(SUBMITTED, GENERATING, FAILED, UNKNOWN, CANCELLED);
                break;
            case SUBMITTED:
                allowed = EnumSet.of(QUEUED, GENERATING, DOWNLOADING, FAILED, UNKNOWN, CANCELLED);
                break;
            case QUEUED:
                allowed = EnumSet.of(GENERATING, FAILED, UNKNOWN, CANCELLED);
                break;
            case GENERATING:
                allowed = EnumSet.of(DOWNLOADING, PROCESSING, FAILED, UNKNOWN, CANCELLED);
                break;
            case DOWNLOADING:
                allowed = EnumSet.of(PROCESSING, VALIDATING_OUTPUT, FAILED, UNKNOWN, CANCELLED);
                break;
            case PROCESSING:
                allowed = EnumSet.of(VALIDATING_OUTPUT, COMPLETED, FAILED, UNKNOWN);
                break;
            case VALIDATING_OUTPUT:
                allowed = EnumSet.of(COMPLETED, FAILED);
                break;
            case RETRYING:
                allowed = EnumSet.of(VALIDATING, UPLOADING, SUBMITTED, GENERATING, FAILED, UNKNOWN, CANCELLED);
                break;
            case UNKNOWN:
                allowed = EnumSet.of(RETRYING, FAILED, CANCELLED, COMPLETED);
                break;
            case FAILED:
                allowed = EnumSet.of(RETRYING, CANCELLED);
                break;
            case CANCELLED:
            case COMPLETED:
            default:
                allowed = EnumSet.noneOf(GenerationJobState.class);
        }
        return allowed.contains(next);
    }
}
