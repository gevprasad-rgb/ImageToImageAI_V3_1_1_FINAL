package com.prasad.image2image.provider;

public final class ProviderReconciliation {
    public enum Status { NOT_FOUND, PENDING, COMPLETED, AMBIGUOUS }

    public final Status status;
    public final ProviderResult result;
    public final String providerJobId;

    private ProviderReconciliation(Status status, ProviderResult result, String providerJobId) {
        this.status = status;
        this.result = result;
        this.providerJobId = providerJobId == null ? "" : providerJobId;
    }

    public static ProviderReconciliation notFound() { return new ProviderReconciliation(Status.NOT_FOUND, null, ""); }
    public static ProviderReconciliation pending(String providerJobId) { return new ProviderReconciliation(Status.PENDING, null, providerJobId); }
    public static ProviderReconciliation completed(ProviderResult result) { return new ProviderReconciliation(Status.COMPLETED, result, result == null ? "" : result.providerJobId); }
    public static ProviderReconciliation ambiguous(String providerJobId) { return new ProviderReconciliation(Status.AMBIGUOUS, null, providerJobId); }
}
