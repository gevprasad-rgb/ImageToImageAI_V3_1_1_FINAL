package com.prasad.image2image.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface GenerationJobDao {
    @Insert
    long insert(GenerationJobEntity job);

    @Update
    void update(GenerationJobEntity job);

    @Query("SELECT * FROM generation_jobs ORDER BY createdAt DESC LIMIT :limit")
    java.util.List<GenerationJobEntity> getRecent(int limit);

    @Query("SELECT * FROM generation_jobs WHERE id = :id LIMIT 1")
    GenerationJobEntity findById(long id);

    @Query("SELECT * FROM generation_jobs WHERE state IN ('CREATED','VALIDATING','UPLOADING','SUBMITTED','QUEUED','GENERATING','DOWNLOADING','PROCESSING','VALIDATING_OUTPUT','RETRYING','UNKNOWN') ORDER BY updatedAt ASC")
    java.util.List<GenerationJobEntity> getPendingJobs();
}
