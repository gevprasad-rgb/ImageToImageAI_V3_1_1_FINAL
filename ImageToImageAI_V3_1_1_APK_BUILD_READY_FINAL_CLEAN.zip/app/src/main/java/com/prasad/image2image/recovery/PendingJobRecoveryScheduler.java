package com.prasad.image2image.recovery;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.BackoffPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class PendingJobRecoveryScheduler {
    private static final String UNIQUE_NAME = "image_to_image_pending_job_recovery";

    private PendingJobRecoveryScheduler() {}

    public static void schedule(Context context) {
        enqueue(context, 0);
    }

    public static void scheduleAfterSubmissionWindow(Context context) {
        enqueue(context, 60);
    }

    private static void enqueue(Context context, long initialDelaySeconds) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(PendingJobRecoveryWorker.class)
                .setConstraints(constraints)
                .setInitialDelay(initialDelaySeconds, TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(UNIQUE_NAME, ExistingWorkPolicy.KEEP, request);
    }
}
