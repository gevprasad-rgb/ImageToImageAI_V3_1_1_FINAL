package com.prasad.image2image.recovery;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.prasad.image2image.data.GenerationJobEntity;
import com.prasad.image2image.data.GenerationRepository;
import com.prasad.image2image.domain.GenerationJobState;
import com.prasad.image2image.provider.ComfyUiProviderAdapter;
import com.prasad.image2image.provider.ProviderReconciliation;
import com.prasad.image2image.provider.ProviderResult;
import com.prasad.image2image.security.SecureCredentialStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

public final class PendingJobRecoveryWorker extends Worker {
    private static final String PREFS = "image_to_image_ai_preferences";
    private static final String PREF_BACKEND = "backend_url";

    public PendingJobRecoveryWorker(@NonNull Context appContext, @NonNull WorkerParameters workerParams) {
        super(appContext, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        GenerationRepository repository = GenerationRepository.getInstance(getApplicationContext());
        SharedPreferences prefs = getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String backend = prefs.getString(PREF_BACKEND, "");
        if (backend == null || backend.trim().isEmpty()) return Result.success();
        final String token;
        try { token = new SecureCredentialStore(getApplicationContext()).getBackendToken(); }
        catch (Exception e) { return Result.failure(); }

        boolean shouldRetry = false;
        List<GenerationJobEntity> jobs = repository.pendingJobs();
        for (GenerationJobEntity job : jobs) {
            if (isStopped()) return Result.retry();
            if (!ComfyUiProviderAdapter.PROVIDER_ID.equals(job.providerId)) continue;
            GenerationJobState currentState = safeState(job.state);
            if (currentState == GenerationJobState.CREATED || currentState == GenerationJobState.VALIDATING || currentState == GenerationJobState.UPLOADING) continue;
            try {
                ProviderReconciliation reconciliation = new ComfyUiProviderAdapter(backend, token).reconcile(job.clientRequestId);
                if (reconciliation.status == ProviderReconciliation.Status.COMPLETED && reconciliation.result != null) {
                    ProviderResult result = reconciliation.result;
                    validateResultBytes(result.bytes, result.width, result.height);
                    String path = persistResult(job.id, result.bytes);
                    moveToCompleted(repository, job.id, result, path);
                } else if (reconciliation.status == ProviderReconciliation.Status.PENDING) {
                    GenerationJobState current = safeState(job.state);
                    if (current == GenerationJobState.UNKNOWN) repository.updateState(job.id, GenerationJobState.RETRYING, null);
                    if (current == GenerationJobState.RETRYING) repository.updateState(job.id, GenerationJobState.GENERATING, null);
                    shouldRetry = true;
                } else if (reconciliation.status == ProviderReconciliation.Status.AMBIGUOUS) {
                    repository.updateState(job.id, GenerationJobState.UNKNOWN, "Provider job state remains ambiguous; automatic resubmission is blocked.");
                } else if (reconciliation.status == ProviderReconciliation.Status.NOT_FOUND) {
                    repository.updateState(job.id, GenerationJobState.UNKNOWN, "Provider has no record of this request; automatic resubmission is blocked.");
                }
            } catch (Exception e) {
                shouldRetry = true;
            }
        }
        return shouldRetry ? Result.retry() : Result.success();
    }

    private String persistResult(long jobId, byte[] bytes) throws Exception {
        if (bytes == null || bytes.length < 24) throw new Exception("Invalid reconciled result");
        File dir = new File(getApplicationContext().getFilesDir(), "assets/results");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Unable to create asset directory");
        File file = new File(dir, "job_" + jobId + ".png");
        try (OutputStream out = new FileOutputStream(file)) { out.write(bytes); }
        return file.getAbsolutePath();
    }

    private void moveToCompleted(GenerationRepository repository, long jobId, ProviderResult result, String path) {
        GenerationJobState current;
        try {
            GenerationJobEntity job = repository.findJob(jobId);
            current = job == null ? GenerationJobState.UNKNOWN : safeState(job.state);
        } catch (Exception e) { current = GenerationJobState.UNKNOWN; }
        if (current != GenerationJobState.UNKNOWN && current != GenerationJobState.GENERATING && current != GenerationJobState.DOWNLOADING && current != GenerationJobState.PROCESSING && current != GenerationJobState.VALIDATING_OUTPUT && current != GenerationJobState.SUBMITTED && current != GenerationJobState.QUEUED && current != GenerationJobState.RETRYING) {
            return;
        }
        repository.markCompleted(jobId, result.providerJobId, path, result.width, result.height, result.mimeType);
    }


    private void validateResultBytes(byte[] bytes, int width, int height) throws Exception {
        if (bytes == null || bytes.length < 24) throw new Exception("Invalid reconciled result");
        if ((bytes[0] & 0xff) != 0x89 || bytes[1] != 0x50 || bytes[2] != 0x4e || bytes[3] != 0x47 ||
                bytes[4] != 0x0d || bytes[5] != 0x0a || bytes[6] != 0x1a || bytes[7] != 0x0a) {
            throw new Exception("Reconciled result is not a PNG");
        }
        if (width <= 0 || height <= 0 || width > 8192 || height > 8192 || (long) width * height > 80_000_000L) {
            throw new Exception("Reconciled result dimensions are invalid");
        }
        int encodedWidth = ((bytes[16] & 0xff) << 24) | ((bytes[17] & 0xff) << 16) | ((bytes[18] & 0xff) << 8) | (bytes[19] & 0xff);
        int encodedHeight = ((bytes[20] & 0xff) << 24) | ((bytes[21] & 0xff) << 16) | ((bytes[22] & 0xff) << 8) | (bytes[23] & 0xff);
        if (encodedWidth != width || encodedHeight != height) throw new Exception("Reconciled result dimensions do not match metadata");
    }

    private GenerationJobState safeState(String value) {
        try { return GenerationJobState.valueOf(value); } catch (Exception e) { return GenerationJobState.UNKNOWN; }
    }
}
