package com.prasad.image2image.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "generation_jobs")
public class GenerationJobEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long projectId;
    public String clientRequestId;
    public String taskId;
    public String providerId;
    public String providerJobId;
    public String model;
    public String prompt;
    public String negativePrompt;
    public String parametersJson;
    public String sourceUri;
    public String resultPath;
    public String mimeType;
    public String state;
    public String errorMessage;
    public int width;
    public int height;
    public long createdAt;
    public long updatedAt;

    public GenerationJobEntity() {}

    public GenerationJobEntity(long projectId, String clientRequestId, String taskId,
                               String providerId, String model, String prompt,
                               String negativePrompt, String parametersJson, String sourceUri,
                               String state, long now) {
        this.projectId = projectId;
        this.clientRequestId = clientRequestId;
        this.taskId = taskId;
        this.providerId = providerId;
        this.model = model;
        this.prompt = prompt;
        this.negativePrompt = negativePrompt;
        this.parametersJson = parametersJson;
        this.sourceUri = sourceUri;
        this.state = state;
        this.createdAt = now;
        this.updatedAt = now;
    }
}
