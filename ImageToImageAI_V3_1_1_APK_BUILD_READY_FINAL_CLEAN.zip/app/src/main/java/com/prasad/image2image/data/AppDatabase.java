package com.prasad.image2image.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {ProjectEntity.class, GenerationJobEntity.class}, version = 1, exportSchema = true)
public abstract class AppDatabase extends RoomDatabase {
    public abstract ProjectDao projectDao();
    public abstract GenerationJobDao generationJobDao();
}
