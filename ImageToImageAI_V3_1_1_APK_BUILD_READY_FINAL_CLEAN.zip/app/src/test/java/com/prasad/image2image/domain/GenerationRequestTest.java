package com.prasad.image2image.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class GenerationRequestTest {
    @Test public void parametersContainStableFields() {
        GenerationRequest request = new GenerationRequest(
                "req-1", TaskId.IMAGE_TO_IMAGE, "comfyui-gateway", "a cat", "bad",
                "1:1", "Balanced", "Auto / Backend Default", 58, 7.8f, 36, 123L, "content://source");

        assertNotNull(request);
        String json = request.parametersJson();
        assertTrue(json.contains("\"aspectRatio\":\"1:1\""));
        assertTrue(json.contains("\"profile\":\"Balanced\""));
        assertTrue(json.contains("\"model\":\"Auto / Backend Default\""));
        assertTrue(json.contains("\"preserve\":58"));
        assertTrue(json.contains("\"cfg\":7.8"));
        assertTrue(json.contains("\"steps\":36"));
        assertTrue(json.contains("\"seed\":123"));
        assertEquals("1:1", request.aspectRatio);
        assertEquals(123L, request.seed);
        assertEquals("comfyui-gateway", request.providerId);
        assertEquals(TaskId.IMAGE_TO_IMAGE, request.taskId);
    }

    @Test public void parametersEscapeJsonStrings() {
        GenerationRequest request = new GenerationRequest(
                "req-2", TaskId.TEXT_TO_IMAGE, "gateway", "a cat", "bad",
                "16:9", "Balanced", "Model \"A\"\\B", 0, 7.0f, 20, 1L, "");

        String json = request.parametersJson();
        assertTrue(json.contains("\\\"A\\\""));
        assertTrue(json.contains("\\\\B"));
        assertFalse(json.contains("\nModel"));
    }
}
