@echo off
setlocal
set APP_HOME=%~dp0
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v9.4.1/gradle/wrapper/gradle-wrapper.jar
set EXPECTED=55243ef57851f12b070ad14f7f5bb8302daceeebc5bce5ece5fa6edb23e1145c
if not exist "%WRAPPER_JAR%" powershell -NoProfile -ExecutionPolicy Bypass -Command "$tmp='%WRAPPER_JAR%.tmp'; Invoke-WebRequest -UseBasicParsing '%WRAPPER_URL%' -OutFile $tmp; $actual=(Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower(); if($actual -ne '%EXPECTED%'){Remove-Item $tmp -Force; exit 1}; Move-Item -Force $tmp '%WRAPPER_JAR%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$actual=(Get-FileHash '%WRAPPER_JAR%' -Algorithm SHA256).Hash.ToLower(); if($actual -ne '%EXPECTED%'){exit 1}"
java %JAVA_OPTS% %GRADLE_OPTS% -Dorg.gradle.appname=gradlew -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
