import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from backend import server


class ContractTests(unittest.TestCase):
    def setUp(self):
        server.RATE_BUCKETS.clear()

    def test_required_tasks_are_explicit(self):
        self.assertEqual(server.SUPPORTED_TASKS, ["TEXT_TO_IMAGE", "IMAGE_TO_IMAGE"])
        self.assertIn("1:1", server.SUPPORTED_RATIOS)
        self.assertIn("9:16", server.SUPPORTED_RATIOS)
        self.assertIn("16:9", server.SUPPORTED_RATIOS)

    def test_target_sizes_are_stable(self):
        self.assertEqual(server.target_size("1:1"), (1024, 1024))
        self.assertEqual(server.target_size("9:16"), (768, 1344))
        self.assertEqual(server.target_size("16:9"), (1344, 768))

    def test_i2i_workflow_contains_source_loader(self):
        graph = server.workflow_i2i("source.png", "prompt", "negative", "model", 1, 30, 7.5, 0.5, 1024, 1024)
        self.assertEqual(graph["20"]["class_type"], "LoadImage")
        self.assertEqual(graph["50"]["class_type"], "KSampler")

    def test_txt2img_workflow_contains_empty_latent(self):
        graph = server.workflow_txt2img("prompt", "negative", "model", 1, 30, 7.5, 1024, 1024)
        self.assertEqual(graph["20"]["class_type"], "EmptyLatentImage")
        self.assertEqual(graph["70"]["class_type"], "SaveImage")

    def test_public_bind_requires_gateway_token(self):
        old_host, old_token = server.HOST, server.APP_TOKEN
        try:
            server.HOST, server.APP_TOKEN = "0.0.0.0", ""
            with self.assertRaises(Exception):
                server.auth(None)
        finally:
            server.HOST, server.APP_TOKEN = old_host, old_token

    def test_loopback_can_run_without_gateway_token(self):
        old_host, old_token = server.HOST, server.APP_TOKEN
        try:
            server.HOST, server.APP_TOKEN = "127.0.0.1", ""
            server.auth(None)
        finally:
            server.HOST, server.APP_TOKEN = old_host, old_token

    def test_request_hash_changes_when_payload_changes(self):
        a = server.request_hash("TEXT_TO_IMAGE", "cat", "", "1:1", "Balanced", "model", 95, 7.0, 30, 123, None)
        b = server.request_hash("TEXT_TO_IMAGE", "dog", "", "1:1", "Balanced", "model", 95, 7.0, 30, 123, None)
        self.assertNotEqual(a, b)

    def test_idempotency_ledger_round_trip(self):
        old_upload, old_db = server.UPLOAD_DIR, server.DB_PATH
        try:
            with tempfile.TemporaryDirectory() as tmp:
                server.UPLOAD_DIR = __import__("pathlib").Path(tmp)
                server.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
                server.DB_PATH = server.UPLOAD_DIR / "jobs.sqlite3"
                server.put_job("req-1", "hash-1", "QUEUED", prompt_id="provider-1")
                row = server.get_job("req-1")
                self.assertEqual(row[0], "req-1")
                self.assertEqual(row[1], "hash-1")
                self.assertEqual(row[2], "provider-1")
                self.assertEqual(row[3], "QUEUED")
        finally:
            server.UPLOAD_DIR, server.DB_PATH = old_upload, old_db

    def test_capabilities_endpoint_exposes_only_real_tasks(self):
        old_host, old_token = server.HOST, server.APP_TOKEN
        try:
            server.HOST, server.APP_TOKEN = "127.0.0.1", ""
            response = TestClient(server.app).get("/capabilities")
            self.assertEqual(response.status_code, 200)
            body = response.json()
            self.assertEqual(body["supportedTasks"], ["TEXT_TO_IMAGE", "IMAGE_TO_IMAGE"])
            self.assertEqual(body["exactVideoDurationSeconds"], 0.0)
        finally:
            server.HOST, server.APP_TOKEN = old_host, old_token

    def test_idempotent_replay_returns_same_result_without_requeue(self):
        old_host, old_token, old_db = server.HOST, server.APP_TOKEN, server.DB_PATH
        old_download = server.download_output
        try:
            server.HOST, server.APP_TOKEN = "127.0.0.1", ""
            with tempfile.TemporaryDirectory() as tmp:
                server.DB_PATH = Path(tmp) / "jobs.sqlite3"
                req = "replay-req"
                req_hash = server.request_hash("TEXT_TO_IMAGE", "cat", "", "1:1", "Balanced", server.DEFAULT_MODEL, 95, 7.0, 30, 123, None)
                server.put_job(req, req_hash, "COMPLETED", prompt_id="provider-1", filename="out.png", subfolder="", folder_type="output")
                server.download_output = lambda *args, **kwargs: b"\x89PNG\r\n\x1a\n" + b"0" * 100
                response = TestClient(server.app).post("/generate", data={
                    "task_id": "TEXT_TO_IMAGE", "prompt": "cat", "negative_prompt": "", "aspect_ratio": "1:1",
                    "profile": "Balanced", "model": server.DEFAULT_MODEL, "preserve": "95", "cfg": "7.0",
                    "steps": "30", "seed": "123", "output_format": "png", "client_request_id": req
                })
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.headers.get("X-Idempotent-Replay"), "true")
                self.assertEqual(response.content, b"\x89PNG\r\n\x1a\n" + b"0" * 100)
        finally:
            server.HOST, server.APP_TOKEN, server.DB_PATH = old_host, old_token, old_db
            server.download_output = old_download

    def test_ambiguous_existing_job_blocks_resubmission(self):
        old_host, old_token, old_db = server.HOST, server.APP_TOKEN, server.DB_PATH
        try:
            server.HOST, server.APP_TOKEN = "127.0.0.1", ""
            with tempfile.TemporaryDirectory() as tmp:
                server.DB_PATH = Path(tmp) / "jobs.sqlite3"
                req = "ambiguous-req"
                req_hash = server.request_hash("TEXT_TO_IMAGE", "cat", "", "1:1", "Balanced", server.DEFAULT_MODEL, 95, 7.0, 30, 123, None)
                server.put_job(req, req_hash, "UNKNOWN", prompt_id="provider-unknown")
                response = TestClient(server.app).post("/generate", data={
                    "task_id": "TEXT_TO_IMAGE", "prompt": "cat", "negative_prompt": "", "aspect_ratio": "1:1",
                    "profile": "Balanced", "model": server.DEFAULT_MODEL, "preserve": "95", "cfg": "7.0",
                    "steps": "30", "seed": "123", "output_format": "png", "client_request_id": req
                })
                self.assertEqual(response.status_code, 409)
                self.assertIn("ambiguous", response.json()["detail"].lower())
        finally:
            server.HOST, server.APP_TOKEN, server.DB_PATH = old_host, old_token, old_db

    def test_claim_job_is_atomic_and_preserves_creation_time(self):
        old_upload, old_db = server.UPLOAD_DIR, server.DB_PATH
        try:
            with tempfile.TemporaryDirectory() as tmp:
                server.UPLOAD_DIR = Path(tmp)
                server.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
                server.DB_PATH = server.UPLOAD_DIR / "jobs.sqlite3"
                claimed, row = server.claim_job("atomic-1", "hash-a")
                self.assertTrue(claimed)
                self.assertEqual(row[3], "SUBMITTING")
                created = row[7]
                server.put_job("atomic-1", "hash-a", "QUEUED", prompt_id="p1")
                row2 = server.get_job("atomic-1")
                self.assertEqual(row2[3], "QUEUED")
                self.assertEqual(row2[2], "p1")
                self.assertEqual(row2[7], created)
                claimed_again, row3 = server.claim_job("atomic-1", "hash-a")
                self.assertFalse(claimed_again)
                self.assertEqual(row3[3], "QUEUED")
        finally:
            server.UPLOAD_DIR, server.DB_PATH = old_upload, old_db

    def test_profile_validation_rejects_out_of_contract_values(self):
        with self.assertRaises(Exception):
            server.profile_settings("NotAProfile", 95, 7.0, 30)
        with self.assertRaises(Exception):
            server.profile_settings("Balanced", 100, 7.0, 30)
        with self.assertRaises(Exception):
            server.profile_settings("Balanced", 95, 0.5, 30)
        with self.assertRaises(Exception):
            server.profile_settings("Balanced", 95, 7.0, 61)

    def test_png_validator_rejects_non_png(self):
        with self.assertRaises(Exception):
            server.validate_png_bytes(b"not-an-image")


if __name__ == "__main__":
    unittest.main()
