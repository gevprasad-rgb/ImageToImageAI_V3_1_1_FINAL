# ImageToImageAI V3.1.1 Feature Matrix

| Feature | Task ID | UI | Domain/State | Repository | Provider Adapter | Persistence | Tests | V3.1 status |
|---|---|---|---|---|---|---|---|---|
| Text to Image | TEXT_TO_IMAGE | Task selector + prompt + controls | GenerationRequest / job states | GenerationRepository | ComfyUiProviderAdapter | Room job + result asset | Request/state tests | IMPLEMENTED, live provider UNVERIFIED |
| Image to Image | IMAGE_TO_IMAGE | Task selector + source + controls | GenerationRequest / job states | GenerationRepository | ComfyUiProviderAdapter | Room job + result asset | State/request tests | PRESERVED + REFACTORED, live provider UNVERIFIED |
| Negative prompt | provider-dependent | Prompt card | GenerationRequest | Provider adapter | ComfyUI gateway | Room parameters | Request serialization test | IMPLEMENTED for current adapter |
| Ratios | provider-dependent | Aspect selector | Request | Repository | ComfyUI gateway | Room parameters | Request test | IMPLEMENTED: 1:1, 9:16, 16:9, 4:5, 3:4 |
| Model selection | provider-dependent | Model selector + refresh | Capability query | Provider adapter | ComfyUI gateway | Not persisted as catalog yet | Not yet | PARTIAL |
| Save | n/a | Result Save | n/a | n/a | n/a | MediaStore | Manual smoke pending | IMPLEMENTED |
| Share | n/a | Result Share | n/a | n/a | n/a | MediaStore temporary export | Manual smoke pending | IMPLEMENTED |
| History | n/a | History dialog | Job state model | GenerationRepository | n/a | Room | Query path present | IMPLEMENTED |
| Projects | n/a | Default project membership | Project entity | GenerationRepository | n/a | Room | Migration coverage for current v1 schema pending; no destructive upgrade path introduced | PARTIAL: default project membership only; full project management next |
| Revisions | n/a | Use result as source | Result lineage | GenerationRepository | ComfyUI | Job/source URI lineage | Not yet | PARTIAL |
| Retry/recovery | n/a | No automatic retry | UNKNOWN/RETRYING state model | Durable job record | Provider adapter | Room | State-machine tests | IMPLEMENTED: reconciliation + process-death worker; retry UI/manual resolution next |
| Secure backend token | n/a | Token field | Security store | n/a | Adapter receives decrypted token | Keystore-backed AES/GCM | Device test pending | IMPLEMENTED |
| Provider capability | n/a | Unsupported tasks not exposed | Capability model | n/a | /capabilities | n/a | Capability contract pending | IMPLEMENTED for current gateway |
| Image-to-video 8s | IMAGE_TO_VIDEO_8S | Hidden | Task ID exists | n/a | No video adapter | n/a | n/a | NOT IMPLEMENTED / NOT EXPOSED |
| Prompt enhancement | n/a | Hidden | n/a | n/a | No real enhancer | n/a | n/a | NOT IMPLEMENTED / NOT EXPOSED |
| Advanced editing/video | multiple IDs | Hidden | IDs reserved | n/a | No adapters | n/a | n/a | NOT IMPLEMENTED / NOT EXPOSED |
