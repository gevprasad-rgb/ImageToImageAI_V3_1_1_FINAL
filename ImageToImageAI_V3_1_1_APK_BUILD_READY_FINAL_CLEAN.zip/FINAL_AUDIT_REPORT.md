# ImageToImageAI V3.1.1 — Final APK Build-Readiness Audit

## Scope

Audit target: preserved ImageToImageAI V3.1.1 BUILD3-derived source package, followed by a CI-discovered defect correction.

Method: inventory → source/config review → targeted fixes → static verification → clean packaging → checksum verification.

## CI-discovered defects and corrections

1. Backend contract tests initially failed because Starlette TestClient requires `httpx2`. The final source package declares `httpx2==2.13.1` in `backend/requirements.txt`, and CI installs from that requirements file.
2. Android JVM unit test `GenerationRequestTest` then failed at object construction in the Android framework stub environment because the domain class referenced Android `org.json`. The domain serializer was replaced with framework-independent JSON serialization, with explicit escaping tests.
3. The stale direct-source workflow was removed from the source archive so the archive-backed repository has one canonical CI workflow.

## Verification performed

- Backend contract/integration tests: PASS in GitHub CI after dependency correction.
- Python compileall: PASS.
- Dependency-free Java compile/harness for `GenerationRequest`: PASS.
- Android XML/static checks: PASS.
- GitHub Actions YAML parse: PASS.
- Bash syntax checks: PASS.
- Source checksum manifest: regenerated and verified.
- Stale generated artifact scan: PASS.
- Obvious secret-pattern/source hygiene scan: PASS.

## Build contract

Application ID: `com.prasad.image2image`.
Version: `3.1.1` / versionCode `32`.
Android: minSdk `29`, compileSdk/targetSdk `36`.
Toolchain: AGP `9.2.0`, Gradle `9.4.1`, JDK `17`.

## APK execution truth

A successful GitHub Actions run is required to establish Gradle build success, lint/unit-test success, APK creation, APK alignment/signature/package/version inspection, and APK SHA-256 provenance.

Device installation/runtime smoke, Android 10 runtime behavior, and live provider generation remain separate verification gates.
