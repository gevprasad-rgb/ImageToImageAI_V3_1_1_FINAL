# ImageToImageAI V3.1.1 — Final APK Build-Readiness Audit

## Scope

Audit target: preserved `ImageToImageAI_V3_1_1_BUILD3.zip` source tree.

Method: inventory → source/config review → targeted defect fixes → static/contract verification → clean packaging → source checksum verification.

The original uploaded ZIP was preserved unchanged. All edits were made only in a clean extracted working copy.

## Fixed defects

### Build / CI

- Corrected the Gradle wrapper bootstrap URL. The previous `services.gradle.org/...-wrapper.jar` path was invalid for a wrapper JAR; the script now uses the official Gradle v9.4.1 wrapper JAR source URL and verifies the published SHA-256.
- Added the missing archive-backed GitHub Actions workflow at `.github/workflows/build-apk-archive.yml`.
- Kept Android Gradle Plugin 9.2.0, Gradle 9.4.1, JDK 17, compileSdk/targetSdk 36 and minSdk 29 aligned with the declared build contract.
- Added clean archive extraction, source checksum, stale-artifact and APK inspection gates to the archive workflow.

### Provider / generation reliability

- Added an atomic SQLite `clientRequestId` claim before any provider submission, closing the duplicate-request race.
- Preserved immutable job creation time during state updates.
- Added ComfyUI terminal error/failed-state detection so failed provider jobs do not poll until timeout.
- Added strict PNG signature + decode verification and bounded dimensions/pixel count for provider output.
- Added server-side range validation for profile, preservation, CFG and steps.
- Preserved seed `0` as a valid deterministic seed instead of silently replacing it with a random seed.
- Changed image-to-image multipart declaration from JPEG to PNG to match the actual prepared bytes.

### Android recovery / data safety

- HTTP 5xx provider responses are treated as ambiguous/reconcilable instead of being converted to a normal failure that could suppress recovery.
- Recovery worker skips pre-submission states so it cannot claim a foreground job before provider submission.
- Reconciled output is signature- and dimension-validated before persistence.
- Failed MediaStore writes delete the pending row instead of leaving `IS_PENDING=1` orphaned media.
- Backend URL scheme validation is case-insensitive.

### Source hygiene

- Removed generated `__pycache__`, APK/build output, Gradle cache and other stale generated artifacts.
- Regenerated `SOURCE_SHA256SUMS.txt` after the final source changes.

## Verification performed

- Backend contract/integration tests: **14/14 PASS**.
- Python compileall: **PASS**.
- Android XML parse: **PASS**.
- Java structural delimiter audit: **PASS**.
- Bash syntax checks: **PASS**.
- GitHub Actions YAML parse: **PASS** for direct and archive-backed workflows.
- Source checksum manifest: **PASS** — 64 source files covered, 0 missing, 0 extra, 0 mismatched.
- Stale generated artifact scan: **PASS**.
- Obvious secret-pattern/source hygiene scan: **PASS**.

## APK execution truth

This preparation container cannot honestly produce the APK because it has no Android SDK and cannot reach the network to bootstrap the missing Gradle wrapper JAR/distribution.

Therefore:

- Full Android Gradle build: **NOT VERIFIED HERE**.
- APK generation: **NOT GENERATED HERE**.
- APK zipalign/apksigner/aapt inspection: **NOT RUN HERE**.
- APK install/launch/runtime smoke: **NOT VERIFIED**.
- Android 10 runtime smoke: **NOT VERIFIED**.
- Live ComfyUI/provider generation: **NOT VERIFIED**.
- Signed release APK: **NOT PROVIDED**; signing keys are not embedded in source.

## Build contract

The final source package is **CI build-ready**, not an already verified APK.

A successful GitHub Actions archive-backed run is required to establish:

1. Gradle configuration/build success.
2. Android lint and unit-test success.
3. Debug APK creation.
4. APK alignment/signature/package/version inspection.
5. APK SHA-256 provenance.

Device installation/runtime and live-provider tests are separate gates.
