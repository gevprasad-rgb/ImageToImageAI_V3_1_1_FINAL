package com.prasad.image2image.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class GenerationRequestTest {
    @Test public void parametersContainStableFields() {
        GenerationRequest request = new GenerationRequest(
                "req-1", TaskId.IMAGE_TO_IMAGE, "comfyui-gateway", "a cat", "bad",
                "1:1", "Balanced", "Auto / Backend Default", 58, 7.8f, 36, 123L, "content://source");

        assertNotNull(request);
        assertEquals("1:1", request.aspectRatio);
        assertEquals(123L, request.seed);
        assertEquals("comfyui-gateway", request.providerId);
        assertEquals(TaskId.IMAGE_TO_IMAGE, request.taskId);
    }
}
